// `expect` is used here only when re-locking the session manager's
// own mutex; a poisoned mutex means an earlier panic in our own
// code, the daemon is unrecoverable, and propagating via `expect`
// keeps the error type set small (mirrors the pattern in
// `zwhisper_core::audio::recorder`).
#![allow(clippy::expect_used)]

//! Single-session policy state machine.
//!
//! M3 ships a daemon that runs **at most one** recording at a time
//! (M3-plan § "Single-session policy"). The session manager is the
//! exclusive guardian of that invariant: every `StartRecording`
//! D-Bus call goes through [`SessionManager::try_reserve`], every
//! lifecycle-task exit (including failures) goes through
//! [`SessionManager::release`].
//!
//! Per stress-test correction C5, the slot is released **before** the
//! transcribe step starts, so a follow-up `StartRecording` arriving
//! during transcription succeeds. The transcribe future runs after
//! release and emits its `TranscriptComplete` signal under the
//! original `session_id` regardless of which session is active by
//! then.

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};

use tokio::task::JoinHandle;
use zwhisper_core::audio::state::{SessionId, StopReason};
use zwhisper_ipc::RpcError;

/// Type-erased "stop" hook installed by the lifecycle task. When
/// `Recorder1.StopRecording` lands, the daemon calls this with the
/// requested [`StopReason`]; the hook forwards it into the recorder's
/// own `tokio::sync::watch` channel via `Recorder::request_stop`.
pub(crate) type StopHook = Arc<dyn Fn(StopReason) + Send + Sync + 'static>;

/// One in-flight recording. The `recorder` is consumed by the
/// lifecycle task when it calls `Recorder::await_completion`, so we
/// keep a copy of the bookkeeping on this struct (`session_id`,
/// `profile_name`, `started_at`) for `GetStatus`.
pub(crate) struct ActiveSession {
    pub(crate) session_id: SessionId,
    pub(crate) profile_name: String,
    pub(crate) started_at: std::time::Instant,
    /// Hook the lifecycle task installs at spawn time so
    /// `StopRecording` (and the SIGTERM handler) can ask the
    /// recorder to drain without holding the recorder itself.
    pub(crate) stop_hook: Option<StopHook>,
}

impl std::fmt::Debug for ActiveSession {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ActiveSession")
            .field("session_id", &self.session_id)
            .field("profile_name", &self.profile_name)
            .field("started_at", &self.started_at)
            .field("stop_hook", &self.stop_hook.as_ref().map(|_| "<fn>"))
            .finish()
    }
}

/// Holds the at-most-one active session. The internal mutex is a
/// std `Mutex` (not tokio) because critical sections are tiny: a
/// single `Option` swap. Holding a `tokio::sync::Mutex` across
/// `await` points adds nothing here and would let the lock straddle
/// signal-emission `await`s.
///
/// `lifecycle_tasks` separately tracks the spawned lifecycle
/// `JoinHandle`s so shutdown can wait for the post-release work
/// (transcription, terminal `StateChanged` emission). The session
/// slot is freed before transcription per C5, so a "slot empty"
/// snapshot is *not* the same as "all background work finished" —
/// the daemon must await the `JoinHandles` before dropping the
/// connection or auto-transcribe gets killed mid-flight and the CLI
/// hangs waiting for `StateChanged "idle"` that never arrives.
#[derive(Default)]
pub(crate) struct SessionManager {
    inner: Mutex<Option<ActiveSession>>,
    lifecycle_tasks: Mutex<Vec<JoinHandle<()>>>,
    /// Counter of `start_recording` calls that have begun but not yet
    /// returned. Shutdown waits for this to drop to zero before
    /// draining `lifecycle_tasks` so a SIGTERM landing in the
    /// `try_reserve` → `spawn_lifecycle` window cannot terminate the
    /// daemon while a freshly-spawned recorder still has no
    /// registered `JoinHandle`.
    inflight_starts: AtomicUsize,
}

impl std::fmt::Debug for SessionManager {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("SessionManager")
            .field("inner", &self.inner)
            .field(
                "lifecycle_tasks",
                &format_args!(
                    "<{} task(s)>",
                    self.lifecycle_tasks.lock().map_or(0, |v| v.len())
                ),
            )
            .field(
                "inflight_starts",
                &self.inflight_starts.load(Ordering::SeqCst),
            )
            .finish()
    }
}

impl SessionManager {
    pub(crate) fn new() -> Self {
        Self::default()
    }

    /// Attempt to claim the single session slot. On success the
    /// caller owns the slot until [`SessionManager::release`] is
    /// called. On contention returns
    /// [`RpcError::SessionInUse`] carrying the existing session id.
    pub(crate) fn try_reserve(
        &self,
        session_id: SessionId,
        profile_name: &str,
    ) -> Result<(), RpcError> {
        let mut slot = self.inner.lock().expect("session manager mutex poisoned");
        if let Some(existing) = slot.as_ref() {
            return Err(RpcError::SessionInUse {
                existing: existing.session_id.to_string(),
            });
        }
        *slot = Some(ActiveSession {
            session_id,
            profile_name: profile_name.to_owned(),
            started_at: std::time::Instant::now(),
            stop_hook: None,
        });
        Ok(())
    }

    /// Install the stop hook for the currently-active session. Must
    /// be called immediately after `try_reserve` succeeds and before
    /// the lifecycle task moves the recorder into `spawn_blocking`.
    /// Silently no-ops when no session is active (defensive — the
    /// only realistic caller is the lifecycle task itself, which
    /// just reserved the slot).
    pub(crate) fn install_stop_hook(&self, hook: StopHook) {
        let mut slot = self.inner.lock().expect("session manager mutex poisoned");
        if let Some(session) = slot.as_mut() {
            session.stop_hook = Some(hook);
        }
    }

    /// Forward a `StopReason` to the active session's stop hook.
    /// Idempotent — calling twice in a row just sends the reason
    /// twice; the recorder's `watch::Sender::send_replace` collapses
    /// them. Returns `false` when no session is active so the caller
    /// can decide whether to surface `RpcError::SessionUnknown`.
    pub(crate) fn request_stop_active(&self, reason: StopReason) -> bool {
        // Clone the hook out under the lock so the actual fn call
        // happens after we drop the mutex; the hook itself runs the
        // recorder's `request_stop` which only touches a channel.
        let hook = {
            let slot = self.inner.lock().expect("session manager mutex poisoned");
            slot.as_ref().and_then(|s| s.stop_hook.clone())
        };
        match hook {
            Some(f) => {
                f(reason);
                true
            }
            None => false,
        }
    }

    /// Atomic `StopRecording` driver: under one lock, validate the
    /// supplied session id, then either fire the installed stop
    /// hook (returning [`StopAttempt::Stopped`]), report that the
    /// session is reserved but its stop hook has not yet been
    /// installed (returning [`StopAttempt::NotReady`] — race window
    /// between `try_reserve` and `install_stop_hook` inside
    /// `start_recording`), or report that no matching session is
    /// active (returning [`StopAttempt::Unknown`]).
    ///
    /// Splitting `matches` and `request_stop_active` into two
    /// separate calls let `stop_recording` race against itself and
    /// silently turn a `NotReady` window into a fake `Ok` reply. This
    /// helper rolls both checks under the same mutex.
    pub(crate) fn try_stop(&self, id: &SessionId, reason: StopReason) -> StopAttempt {
        let hook = {
            let slot = self.inner.lock().expect("session manager mutex poisoned");
            match slot.as_ref() {
                Some(active) if active.session_id == *id => match active.stop_hook.clone() {
                    Some(hook) => Some(hook),
                    None => return StopAttempt::NotReady,
                },
                _ => return StopAttempt::Unknown,
            }
        };
        if let Some(f) = hook {
            f(reason);
        }
        StopAttempt::Stopped
    }

    /// Release the session slot. Idempotent — releasing an empty
    /// slot is silently a no-op so the lifecycle task can call this
    /// from both the success and failure branches without
    /// double-bookkeeping.
    pub(crate) fn release(&self) {
        let mut slot = self.inner.lock().expect("session manager mutex poisoned");
        *slot = None;
    }

    /// Snapshot of the active session (if any). Cloned out so the
    /// lock is released before the caller does any signal emission
    /// or other awaitable work.
    pub(crate) fn snapshot(&self) -> Option<SessionSnapshot> {
        let slot = self.inner.lock().expect("session manager mutex poisoned");
        slot.as_ref().map(|s| SessionSnapshot {
            session_id: s.session_id,
            started_at: s.started_at,
        })
    }

    /// RAII guard for an in-flight `start_recording` call. Created
    /// at the very top of `start_recording`, before the first
    /// `await`, so shutdown can detect "a start is in progress, the
    /// lifecycle handle has not been registered yet" and wait for
    /// the call to finish (or fail) instead of dropping the bus
    /// connection mid-spawn.
    pub(crate) fn begin_start(self: &Arc<Self>) -> InflightStartGuard {
        self.inflight_starts.fetch_add(1, Ordering::SeqCst);
        InflightStartGuard {
            sessions: Arc::clone(self),
        }
    }

    /// Snapshot of the in-flight start count. Used by shutdown to
    /// decide whether to wait before draining lifecycle handles.
    pub(crate) fn inflight_starts(&self) -> usize {
        self.inflight_starts.load(Ordering::SeqCst)
    }

    /// Register a lifecycle task's `JoinHandle` so shutdown can
    /// await it. Called by `spawn_lifecycle` immediately after
    /// `tokio::spawn`. Drops handles whose tasks have already
    /// finished so the vec does not grow unbounded across many
    /// short recordings.
    pub(crate) fn register_lifecycle(&self, handle: JoinHandle<()>) {
        let mut tasks = self
            .lifecycle_tasks
            .lock()
            .expect("lifecycle tasks mutex poisoned");
        tasks.retain(|t| !t.is_finished());
        tasks.push(handle);
    }

    /// Take the current set of lifecycle handles. Shutdown awaits
    /// them (with a timeout) before dropping the bus connection so
    /// the post-release transcribe step can finish and the terminal
    /// `StateChanged "idle"` reaches the client.
    pub(crate) fn take_lifecycle_tasks(&self) -> Vec<JoinHandle<()>> {
        let mut tasks = self
            .lifecycle_tasks
            .lock()
            .expect("lifecycle tasks mutex poisoned");
        std::mem::take(&mut *tasks)
    }

    /// Returns whether the supplied `id` matches the currently active
    /// session. Used by `StopRecording` to validate the caller.
    #[allow(dead_code)] // `try_stop` superseded the two-call pattern; helper kept for tests.
    pub(crate) fn matches(&self, id: &SessionId) -> bool {
        let slot = self.inner.lock().expect("session manager mutex poisoned");
        slot.as_ref().is_some_and(|s| s.session_id == *id)
    }
}

/// RAII handle for a `begin_start`. Decrements the in-flight count
/// on drop so `start_recording` cannot leak the counter on any
/// error path (`?`, `return`, panic). The guard intentionally does
/// not own the `SessionManager`; it holds an `Arc` clone so dropping
/// it is cheap and never blocks.
pub(crate) struct InflightStartGuard {
    sessions: Arc<SessionManager>,
}

impl Drop for InflightStartGuard {
    fn drop(&mut self) {
        self.sessions.inflight_starts.fetch_sub(1, Ordering::SeqCst);
    }
}

impl std::fmt::Debug for InflightStartGuard {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("InflightStartGuard").finish()
    }
}

/// Result of [`SessionManager::try_stop`]. Lets the caller
/// distinguish "no such session" from "session reserved but not
/// fully spun up" — the latter must surface as a transient error so
/// callers retry instead of treating it as a successful stop.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum StopAttempt {
    /// Session matched and the stop hook was fired.
    Stopped,
    /// No active session matches the supplied id.
    Unknown,
    /// The session slot is reserved but the lifecycle task has not
    /// installed the stop hook yet — the recording is in the brief
    /// window between `try_reserve` and `spawn_lifecycle`.
    NotReady,
}

/// Lock-free copy of an [`ActiveSession`]'s fields. Returned by
/// [`SessionManager::snapshot`] so callers can read state without
/// holding the manager's mutex across an `await`.
#[derive(Debug, Clone)]
pub(crate) struct SessionSnapshot {
    /// Session id of the active recording. Currently used only by
    /// `Recorder1.GetStatus` for log correlation; kept on the
    /// snapshot so future status fields (e.g. profile name) have a
    /// natural home without re-locking.
    #[allow(dead_code)]
    pub(crate) session_id: SessionId,
    pub(crate) started_at: std::time::Instant,
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::panic)]
mod tests {
    use super::*;

    #[test]
    fn try_reserve_succeeds_when_slot_empty() {
        let mgr = SessionManager::new();
        let id = SessionId::new();
        mgr.try_reserve(id, "default").unwrap();
        assert!(mgr.snapshot().is_some());
    }

    #[test]
    fn second_try_reserve_returns_session_in_use() {
        let mgr = SessionManager::new();
        let first = SessionId::new();
        mgr.try_reserve(first, "default").unwrap();
        let second = SessionId::new();
        let err = mgr.try_reserve(second, "default").unwrap_err();
        match err {
            RpcError::SessionInUse { existing } => {
                assert_eq!(existing, first.to_string());
            }
            other => panic!("expected SessionInUse, got {other:?}"),
        }
    }

    #[test]
    fn release_then_reserve_succeeds() {
        let mgr = SessionManager::new();
        let first = SessionId::new();
        mgr.try_reserve(first, "default").unwrap();
        mgr.release();
        assert!(mgr.snapshot().is_none());
        let second = SessionId::new();
        mgr.try_reserve(second, "default").unwrap();
        assert!(mgr.snapshot().is_some());
    }

    #[test]
    fn release_on_empty_slot_is_noop() {
        let mgr = SessionManager::new();
        mgr.release(); // should not panic
        assert!(mgr.snapshot().is_none());
    }

    #[test]
    fn matches_returns_true_for_active_id_only() {
        let mgr = SessionManager::new();
        let id = SessionId::new();
        mgr.try_reserve(id, "default").unwrap();
        assert!(mgr.matches(&id));
        let other = SessionId::new();
        assert!(!mgr.matches(&other));
    }

    #[test]
    fn matches_returns_false_when_no_session() {
        let mgr = SessionManager::new();
        let id = SessionId::new();
        assert!(!mgr.matches(&id));
    }

    #[test]
    fn try_stop_returns_unknown_when_no_session() {
        let mgr = SessionManager::new();
        let id = SessionId::new();
        assert_eq!(
            mgr.try_stop(&id, StopReason::UserRequested),
            StopAttempt::Unknown,
        );
    }

    #[test]
    fn try_stop_returns_unknown_for_mismatched_id() {
        let mgr = SessionManager::new();
        let active = SessionId::new();
        mgr.try_reserve(active, "default").unwrap();
        let other = SessionId::new();
        assert_eq!(
            mgr.try_stop(&other, StopReason::UserRequested),
            StopAttempt::Unknown,
        );
    }

    #[test]
    fn try_stop_returns_not_ready_when_hook_not_installed() {
        // The race window: try_reserve succeeded but the lifecycle
        // task has not yet called install_stop_hook. Surfacing
        // NotReady lets stop_recording return Transient instead of
        // a fake Ok.
        let mgr = SessionManager::new();
        let id = SessionId::new();
        mgr.try_reserve(id, "default").unwrap();
        assert_eq!(
            mgr.try_stop(&id, StopReason::UserRequested),
            StopAttempt::NotReady,
        );
    }

    #[test]
    fn try_stop_fires_hook_and_returns_stopped() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        let mgr = SessionManager::new();
        let id = SessionId::new();
        mgr.try_reserve(id, "default").unwrap();
        let counter = Arc::new(AtomicUsize::new(0));
        let counter_clone = Arc::clone(&counter);
        mgr.install_stop_hook(Arc::new(move |_| {
            counter_clone.fetch_add(1, Ordering::SeqCst);
        }));
        assert_eq!(
            mgr.try_stop(&id, StopReason::UserRequested),
            StopAttempt::Stopped,
        );
        assert_eq!(counter.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn inflight_start_guard_increments_then_decrements() {
        let mgr = Arc::new(SessionManager::new());
        assert_eq!(mgr.inflight_starts(), 0);
        let g1 = mgr.begin_start();
        assert_eq!(mgr.inflight_starts(), 1);
        let g2 = mgr.begin_start();
        assert_eq!(mgr.inflight_starts(), 2);
        drop(g1);
        assert_eq!(mgr.inflight_starts(), 1);
        drop(g2);
        assert_eq!(mgr.inflight_starts(), 0);
    }

    #[test]
    fn inflight_start_guard_decrements_on_panic_unwind() {
        // RAII via Drop must hold even if the body panics, so the
        // shutdown path cannot wedge on a stuck counter.
        let mgr = Arc::new(SessionManager::new());
        let result = std::panic::catch_unwind({
            let mgr = Arc::clone(&mgr);
            move || {
                let _g = mgr.begin_start();
                assert_eq!(mgr.inflight_starts(), 1);
                panic!("simulated start failure");
            }
        });
        assert!(result.is_err());
        assert_eq!(mgr.inflight_starts(), 0);
    }

    #[test]
    fn lifecycle_tracker_drains_finished_handles() {
        // register_lifecycle prunes finished handles so the vec
        // does not grow unbounded; take_lifecycle_tasks drains.
        let mgr = SessionManager::new();
        let runtime = tokio::runtime::Builder::new_current_thread()
            .build()
            .unwrap();
        let h1 = runtime.spawn(async {});
        let h2 = runtime.spawn(async {});
        mgr.register_lifecycle(h1);
        mgr.register_lifecycle(h2);
        // Nudge the runtime so both tasks complete before we drain.
        runtime.block_on(async { tokio::task::yield_now().await });
        let drained = mgr.take_lifecycle_tasks();
        assert_eq!(drained.len(), 2);
        // Tracker should now be empty.
        assert!(mgr.take_lifecycle_tasks().is_empty());
    }
}
